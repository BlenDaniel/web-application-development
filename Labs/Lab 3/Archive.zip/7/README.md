# Lab 3

### 7. (for 1337 h4x0rz only): Make Your Journal Annoying w/ Hover -- Elegantly