# Lab 3

### 1. Arrange Your Page into Sections