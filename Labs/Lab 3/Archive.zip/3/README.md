# Lab 3

### 3. Float, Alignment and Clear