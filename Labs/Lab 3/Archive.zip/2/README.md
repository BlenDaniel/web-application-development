# Lab 3

### 2. Spacing With Padding and Margins, Backgrounds